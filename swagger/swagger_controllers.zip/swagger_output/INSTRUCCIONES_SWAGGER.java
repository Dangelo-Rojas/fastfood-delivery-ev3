<!-- ============================================================ -->
<!-- PASO 1: Agregar esta dependencia en el pom.xml de CADA microservicio -->
<!-- Dentro de la sección <dependencies> -->
<!-- ============================================================ -->

<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.8.8</version>
</dependency>


<!-- ============================================================ -->
<!-- PASO 2: Crear este archivo en cada microservicio             -->
<!-- Ruta: src/main/java/com/fastfood/{ms}/config/OpenApiConfig.java -->
<!-- ============================================================ -->

/*
 * ARCHIVO: OpenApiConfig.java
 * Crear en: src/main/java/com/fastfood/ms_usuario/config/OpenApiConfig.java
 * (Cambiar el package según el microservicio)
 */

package com.fastfood.ms_usuario.config;  // <-- cambiar por el package correcto de cada ms

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("ms-usuario API")           // <-- cambiar por el nombre del ms
                        .version("1.0.0")
                        .description("Microservicio de gestión de usuarios, regiones, comunas y direcciones"));
                        // <-- cambiar descripción según el ms
    }
}


/* ============================================================
   PACKAGES Y DESCRIPCIONES POR MICROSERVICIO:
   ============================================================

   ms-usuario:
     package: com.fastfood.ms_usuario.config
     title: "ms-usuario API"
     description: "Microservicio de gestión de usuarios, regiones, comunas y direcciones"

   ms-restaurante:
     package: com.fastfood.ms_restaurante.config
     title: "ms-restaurante API"
     description: "Microservicio de gestión de restaurantes, catálogo y promociones"

   ms-orden:
     package: com.fastfood.ms_orden.config
     title: "ms-orden API"
     description: "Microservicio de gestión de órdenes, carritos, pagos y métodos de pago"

   ms-delivery:
     package: com.fastfood.ms_delivery.config
     title: "ms-delivery API"
     description: "Microservicio de gestión de entregas y conductores"

   ============================================================ */


/* ============================================================
   PASO 3: Verificar que en application.properties NO haya
   configuración que bloquee Swagger. Si ves esto, elimínalo:

   spring.mvc.pathmatch.matching-strategy=ant_path_matcher

   Con Spring Boot 4.x y springdoc 2.x NO se necesita.
   ============================================================ */


/* ============================================================
   PASO 4: URL para acceder al Swagger de cada microservicio:

   ms-usuario    → http://localhost:8081/swagger-ui.html
   ms-restaurante → http://localhost:8082/swagger-ui.html
   ms-orden      → http://localhost:8087/swagger-ui.html
   ms-delivery   → http://localhost:8089/swagger-ui.html

   ============================================================ */
